{{/*
Expand the name of the chart.
*/}}
{{- define "stormchaser-runner-k8s.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "stormchaser-runner-k8s.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "stormchaser-runner-k8s.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "stormchaser-runner-k8s.labels" -}}
helm.sh/chart: {{ include "stormchaser-runner-k8s.chart" . }}
{{ include "stormchaser-runner-k8s.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "stormchaser-runner-k8s.selectorLabels" -}}
app.kubernetes.io/name: {{ include "stormchaser-runner-k8s.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "stormchaser-runner-k8s.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "stormchaser-runner-k8s.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Namespace workflow step Jobs run in. It is always separate from the release namespace,
which holds the runner (and, in the umbrella chart, the control plane and its secrets).
*/}}
{{- define "stormchaser-runner-k8s.stepNamespace" -}}
{{- $ns := default (printf "%s-steps" .Release.Namespace) .Values.rbac.targetNamespace }}
{{- if eq $ns .Release.Namespace }}
{{- fail (printf "rbac.targetNamespace must differ from the release namespace %q: workflow steps may not share a namespace with Stormchaser" .Release.Namespace) }}
{{- end }}
{{- $ns }}
{{- end }}
